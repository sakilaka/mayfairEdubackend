<h1>Hi {{ $value['user']->name }},</h1>
<p>Your Reset Code : {{ $value['token'] }}</p>

<p>To reset password use your Reset CODE . it will be expried within 1 hour.</p>

<p style="padding-top:30px;">Thank you</p>


