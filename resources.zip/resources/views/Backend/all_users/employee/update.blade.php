<!DOCTYPE html>
<html lang="en">

<head>
    @include('Backend.components.head')
    <title>{{ env('APP_NAME') }} | Edit Employee</title>
</head>

<body>
    <div class="container-scroller">
        @include('Backend.components.navbar')

        <div class="container-fluid page-body-wrapper">
            @include('Backend.components.sidebar')

            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="page-header">
                        <h3 class="page-title">
                            Edit Employee
                        </h3>

                        <nav aria-label="breadcrumb">
                            <a href="{{ route('backend.admin.manage_employee.index') }}" class="btn btn-primary btn-fw">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                                View All Employee</a>
                        </nav>
                    </div>

                    <div class="row">
                        <div class="col-md-10 m-auto grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <form class="forms-sample"
                                        action="{{ route('backend.admin.manage_employee.update', ['id' => $employee->id]) }}"
                                        method="POST" enctype="multipart/form-data">
                                        @csrf

                                        <div class="form-group row">
                                            <div class="col-sm-3 d-flex justify-content-between align-items-center">
                                                <label for="menu_type" class="col-form-label">Profile Photo</label>
                                                <p>:</p>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-8 col-lg-6">
                                                        <div class="dropify-wrapper" style="border: none">
                                                            <div class="dropify-loader"></div>
                                                            <div class="dropify-errors-container">
                                                                <ul></ul>
                                                            </div>
                                                            <input type="file" class="dropify" name="image"
                                                                accept="image/*" id="thumbnail_upload">
                                                            <button type="button" class="dropify-clear">Remove</button>
                                                            <div class="dropify-preview">
                                                                <span class="dropify-render"></span>
                                                                <div class="dropify-infos">
                                                                    <div class="dropify-infos-inner">
                                                                        <p class="dropify-filename">
                                                                            <span class="file-icon"></span>
                                                                            <span class="dropify-filename-inner"></span>
                                                                        </p>
                                                                        <p class="dropify-infos-message">
                                                                            Drag and drop or click to replace
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="col-sm-12 col-md-4 col-lg-6 d-flex justify-content-center align-items-center">
                                                        <div class="px-3">
                                                            <img src="{{ $employee->image_show ?? asset('frontend/images/No-image.jpg') }}"
                                                                alt="" class="img-fluid"
                                                                style="border-radius: 10px; max-height: 200px !important;"
                                                                id="thumbnail_preview">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Name
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" name="name" class="form-control"
                                                    placeholder="Enter Employee Name" value="{{ $employee->name }}"
                                                    required>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Mobile
                                                    <span class="text-danger">*</span>
                                                </label>

                                                <input type="text" name="mobile" class="form-control"
                                                    placeholder="Enter Mobile Number" value="{{ $employee->mobile }}"
                                                    required>

                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Email
                                                    <span class="text-danger">*</span>
                                                </label>

                                                <input type="email" name="email" class="form-control"
                                                    placeholder="Enter Email" value="{{ $employee->email }}" required>
                                                @error('email')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Password
                                                </label>

                                                <input type="password" name="password" class="form-control"
                                                    placeholder="Enter Password">
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Passport No.
                                                </label>

                                                <input type="text" name="passport_no" class="form-control"
                                                    placeholder="Enter Passport No."
                                                    value="{{ $employee->passport_no }}">
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Employee ID
                                                </label>

                                                <input type="text" name="employee_id" class="form-control"
                                                    value="{{ $employee->employee_id }}" readonly>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Office
                                                    <span class="text-danger">*</span>
                                                </label>

                                                <select name="branch" class="form-control form-control-lg" required>
                                                    <option value="">Select Office</option>
                                                    @foreach ($branches as $branch)
                                                        <option value="{{ $branch->id }}"
                                                            {{ $branch->id == $employee->branch ? 'selected' : '' }}>
                                                            {{ $branch->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label class="col-form-label pt-0">Role
                                                </label>

                                                <select name="role" class="form-control form-control-lg">
                                                    <option value="manager"
                                                        {{ 'manager' == $employee->role ? 'selected' : '' }}>Manager
                                                    </option>
                                                    <option value="support"
                                                        {{ 'support' == $employee->role ? 'selected' : '' }}>Support
                                                    </option>
                                                    <option value="general_employee"
                                                        {{ 'general_employee' == $employee->role ? 'selected' : '' }}>
                                                        General Stuff</option>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-12">
                                                <label class="col-form-label pt-0">Address
                                                </label>

                                                <input type="text" name="address" class="form-control"
                                                    placeholder="Enter Address" value="{{ $employee->address }}">
                                            </div>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                @include('Backend.components.footer')
            </div>
        </div>
    </div>

    @include('Backend.components.script')

    <script src="{{ asset('backend/assets/js/dropify.js') }}"></script>
    <script>
        $('#thumbnail_upload').on('change', function(e) {
            var fileInput = $(this)[0];

            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#thumbnail_preview').attr('src', e.target.result);
                };

                reader.readAsDataURL(fileInput.files[0]);
            }
        });
    </script>

</body>

</html>
